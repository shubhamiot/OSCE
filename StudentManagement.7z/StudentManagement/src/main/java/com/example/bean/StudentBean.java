package com.example.bean;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;


@Entity
@Table(name="student")
public class StudentBean {
	@Id
	private int id;
	@Size(min = 4, message = "Length between 8-20 characters")
	private String fullName;
	@Size(min = 1, message = "Length between 1-6 characters")
	private String address;
	
	public StudentBean()
	{}
	public StudentBean(int id, @Size(min = 4, message = "Length between 8-20 characters") String fullName,
			@Size(min = 1, message = "Length between 1-6 characters") String address) {
		super();
		this.id = id;
		this.fullName = fullName;
		this.address = address;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "StudentBean [id=" + id + ", fullName=" + fullName + ", address=" + address + "]";
	}
	
	
	

}
