package com.cg.train_ticket_reservation.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="mticket")
public class Ticket {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int pnr;
	@NotNull
	private String username;
	@Size(min = 6, message = "Password should be of minimum 6 characters")
	private String password;
	@NotNull
	private String name;
	private String orgin_sta;
	private String boarding_sta;
	private String dest_sta;
	private String coach;
	private String number;
	public Ticket()
	{
		
	}
	public Ticket( String username, String password, String name, String orgin_sta, String boarding_sta,
			String dest_sta, String coach, String number) {
		super();
		this.username = username;
		this.password = password;
		this.name = name;
		this.orgin_sta = orgin_sta;
		this.boarding_sta = boarding_sta;
		this.dest_sta = dest_sta;
		this.coach = coach;
		this.number = number;
	}
	public int getPnr() {
		return pnr;
	}
	public void setPnr(int pnr) {
		this.pnr = pnr;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOrgin_sta() {
		return orgin_sta;
	}
	public void setOrgin_sta(String orgin_sta) {
		this.orgin_sta = orgin_sta;
	}
	public String getBoarding_sta() {
		return boarding_sta;
	}
	public void setBoarding_sta(String boarding_sta) {
		this.boarding_sta = boarding_sta;
	}
	public String getDest_sta() {
		return dest_sta;
	}
	public void setDest_sta(String dest_sta) {
		this.dest_sta = dest_sta;
	}
	public String getCoach() {
		return coach;
	}
	public void setCoach(String coach) {
		this.coach = coach;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	@Override
	public String toString() {
		return "Ticket [pnr=" + pnr + ", username=" + username + ", password=" + password + ", name=" + name
				+ ", orgin_sta=" + orgin_sta + ", boarding_sta=" + boarding_sta + ", dest_sta=" + dest_sta + ", coach="
				+ coach + ", number=" + number + "]";
	}
	
	
	
}
