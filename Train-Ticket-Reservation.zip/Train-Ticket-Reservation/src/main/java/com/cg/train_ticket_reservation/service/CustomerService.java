package com.cg.train_ticket_reservation.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.train_ticket_reservation.model.Ticket;
import com.cg.train_ticket_reservation.repository.*;

@Service
@Transactional
public class CustomerService {
	private final CustomerRepository customerRepository;
	public CustomerService(CustomerRepository cusrepo)
	{
		this.customerRepository=cusrepo;
	}

	public void saveMyTicket(Ticket tic) {
		customerRepository.save(tic);
		
	}

	public List<Ticket> showAllTickets() {
		List<Ticket> cus=new ArrayList<Ticket>();
		for(Ticket tic : customerRepository.findAll())
		{
			cus.add(tic);
		}
		return cus;
	}

	public void deleteTicket(int id) {
		customerRepository.deleteById(id);
	}

	public Optional<Ticket> updateTicket(int id) 
	{
		return customerRepository.findById(id);
	}
	public Ticket findUserPassword(String username, String password)
	{
		return customerRepository.findUserPassword(username, password);
		
	}

	
	
	

}
