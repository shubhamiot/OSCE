package com.cg.train_ticket_reservation.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.train_ticket_reservation.model.Ticket;

public interface CustomerRepository extends JpaRepository<Ticket, Integer> {
	public Ticket findUserPassword(String username, String password);
	
}
