package com.cg.train_ticket_reservation.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.train_ticket_reservation.model.Ticket;
import com.cg.train_ticket_reservation.service.CustomerService;


@RestController
public class TicketController {
	@Autowired
	CustomerService cusser;
	@RequestMapping("/welcome")
	public String Welcome(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_HOME");
		return "ticketbookingpage";
	}
	
	@RequestMapping("/register")
	public String registration(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_REGISTER");
		return "ticketbookingpage";
	}
	
	@PostMapping("/save-user")
	public String registerUser(@ModelAttribute Ticket user, BindingResult bindingResult, HttpServletRequest request) {
		cusser.saveMyTicket(user);
		request.setAttribute("mode", "MODE_HOME");
		return "ticketbookingpage";
	}
	
	@GetMapping("/show-users")
	public String showAllTickets(HttpServletRequest request) {
		request.setAttribute("users", cusser.showAllTickets());
		request.setAttribute("mode", "ALL_USERS");
		return "ticketbookingpage";
	}
	@RequestMapping("/delete-user")
	public String deleteUser(@RequestParam int pnr, HttpServletRequest request) {
		cusser.deleteTicket(pnr);
		request.setAttribute("users", cusser.showAllTickets());
		request.setAttribute("mode", "ALL_USERS");
		return "ticketbookingpage";
	}
	
	@RequestMapping("/edit-user")
	public String editUser(@RequestParam int pnr,HttpServletRequest request) {
		request.setAttribute("user", cusser.updateTicket(pnr));
		request.setAttribute("mode", "MODE_UPDATE");
		return "ticketbookingpage";
	}
	
	@RequestMapping("/login")
	public String login(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_LOGIN");
		return "ticketbookingpage";
	}
	
	@RequestMapping ("/login-user")
	public String loginUser(@ModelAttribute Ticket user, HttpServletRequest request) {
		if(cusser.findUserPassword(user.getUsername(), user.getPassword())!=null) {
			return "bookingpage";
		}
		else {
			request.setAttribute("error", "Invalid Username or Password");
			request.setAttribute("mode", "MODE_LOGIN");
			return "ticketbookingpage";
			
		}
	}

}
