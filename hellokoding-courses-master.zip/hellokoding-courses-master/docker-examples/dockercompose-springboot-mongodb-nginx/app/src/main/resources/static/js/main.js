(function(){
    console.log("Hello World!");
})();