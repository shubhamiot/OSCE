package com.cg.mycode.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mycode.model.Ticket;
import com.cg.mycode.repository.TicketRepository;

@Service
@Transactional
public class TicketDao {
	@Autowired
	TicketRepository ticketRepository;
	/* to generate a Ticket*/
	public Ticket save(Ticket tic)
	{
		return ticketRepository.save(tic);
	}
	
	/* to see all ticket */
	public List<Ticket> findAll()
	{
		return ticketRepository.findAll();
	}
	
	/* to see ticket by pnr */
	public Ticket findOne(Long ticid)
	{
		return ticketRepository.findOne(ticid);
	}
	/* to delete the ticket by pnr*/
	public void delete(Ticket tic)
	{
		ticketRepository.delete(tic);
	}
	
}
