package com.cg.mycode.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.mycode.model.Ticket;

public interface TicketRepository extends JpaRepository<Ticket, Long> {

	Ticket findOne(Long ticid);

}
