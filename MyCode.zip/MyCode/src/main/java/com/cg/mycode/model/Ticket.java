package com.cg.mycode.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

@Entity
@Table(name="tickets")
public class Ticket {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long pnr;
	@NotNull
	private String firstname;
	@NotNull
	private String lastname;
	@NotNull
	private String originstation;
	@NotNull
	private String boardingstation;
	@NotNull
	private String destinationstation;
	@LastModifiedDate
	private Date bookingdate;
	public long getPnr() {
		return pnr;
	}
	public void setPnr(long pnr) {
		this.pnr = pnr;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getOriginstation() {
		return originstation;
	}
	public void setOriginstation(String originstation) {
		this.originstation = originstation;
	}
	public String getBoardingstation() {
		return boardingstation;
	}
	public void setBoardingstation(String boardingstation) {
		this.boardingstation = boardingstation;
	}
	public String getDestinationstation() {
		return destinationstation;
	}
	public void setDestinationstation(String destinationstation) {
		this.destinationstation = destinationstation;
	}
	public Date getBookingdate() {
		return bookingdate;
	}
	public void setBookingdate(Date bookingdate) {
		this.bookingdate = bookingdate;
	}
	
}
