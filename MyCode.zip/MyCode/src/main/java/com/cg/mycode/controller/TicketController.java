package com.cg.mycode.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mycode.dao.TicketDao;
import com.cg.mycode.model.Ticket;

@RestController
@RequestMapping("/ticket")
public class TicketController {
	@Autowired
	TicketDao ticketDao;
	/* to save the ticket into the database */
	@PostMapping("/tickets")
	public Ticket createTicket(@Valid @RequestBody Ticket tic)
	{
		return ticketDao.save(tic);
	}
	
	/* to get all the ticket */
	@GetMapping("/tickets")
	public List<Ticket> getAllTickets()
	{
		return ticketDao.findAll();
	}
	
	/* get ticket by pnr */
	 @GetMapping("tickets/{pnr}")
	 public ResponseEntity<Ticket> getTicketByPnr(@PathVariable(value="pnr") Long tickid)
	 {
		 Ticket tic=ticketDao.findOne(tickid);
		 if(tic==null)
		 {
			 return ResponseEntity.notFound().build();
		 }
		 return ResponseEntity.ok().body(tic);
				 
	 }
	 
	 /* edit the ticket by pnr */
	 @PutMapping("/tickets/{pnr}")
	 public ResponseEntity<Ticket> editTicket(@PathVariable(value="pnr") Long tickid, @Valid @RequestBody Ticket ticketDetails)
	 {
		 Ticket tic=ticketDao.findOne(tickid);
		 if(tic==null)
		 {
			 return ResponseEntity.notFound().build();
		 }
		 tic.setFirstname(ticketDetails.getFirstname());
		 tic.setLastname(ticketDetails.getLastname());
		 tic.setOriginstation(ticketDetails.getOriginstation());
		 tic.setBoardingstation(ticketDetails.getBoardingstation());
		 tic.setDestinationstation(ticketDetails.getDestinationstation());
		 Ticket updateTicket=ticketDao.save(tic); // to save
		 return ResponseEntity.ok().body(updateTicket);
	 }
	 
	 /* delete the ticket */
	 
	 @DeleteMapping("/tickets/{pnr}")
	 public ResponseEntity<Ticket> deleteticket(@PathVariable(value="pnr") Long tickid)
	 {
		 Ticket tic=ticketDao.findOne(tickid);
		 if(tic==null)
		 {
			 return ResponseEntity.notFound().build();
		 }
		 ticketDao.delete(tic);
		 return ResponseEntity.ok().build();
	 }
}
