package com.example.demo.Entity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyCodeApplication.class, args);
	}

}
