package com.cg.train.ticket.reservation.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class TrainTicketSecurity extends WebSecurityConfigurerAdapter {
	@Override
	protected void configure(HttpSecurity http) throws Exception {

//		http.authorizeRequests()
//				// URLs matching for access rights
//				.antMatchers("/welcome").permitAll()
//				//.antMatchers("/logon").hasAnyAuthority("SUPER_USER", "ADMIN_USER", "SITE_USER")
//				.antMatchers("/login").permitAll()
//				.antMatchers("/login-user").hasAnyAuthority("SITE_USER")
//				.antMatchers("/register").permitAll()
//				.antMatchers("/save-user").permitAll()
//				.antMatchers("/homepage").hasAnyAuthority("SITE_USER")
//				.antMatchers("/savetocart").permitAll()
//				.antMatchers("/cartitems").permitAll()
//				.antMatchers("/viewcart").permitAll()
//				.antMatchers("/buyitems").permitAll()
//				.antMatchers("/deletefromcart").permitAll()
//				
//				.anyRequest().authenticated()
//				.and()
//				// form login
//				.csrf().disable().formLogin()
//				.loginPage("/login")
//				.failureUrl("/login?error=true")
//				.defaultSuccessUrl("/login-user")
//				.usernameParameter("username")
//				.passwordParameter("password")
//				.and()
//				// logout
//				.logout()
//				.logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
//				.logoutSuccessUrl("/").and()
//				.exceptionHandling()
//				.accessDeniedPage("/access-denied");
		
		http.authorizeRequests()
			.antMatchers("/loginadmin").permitAll()
			.antMatchers("/login-admin").permitAll()
			.antMatchers("/booking").permitAll()
			.antMatchers("/savebooking").permitAll()
			.antMatchers("/deletebooking").permitAll()
			.antMatchers("/register").permitAll()
			.antMatchers("/saveuser").permitAll()
			.antMatchers("/deleteuser").permitAll()
			.antMatchers("/login").permitAll()
			.antMatchers("/loginuser").permitAll()
			.antMatchers("/booktrain").permitAll()
			.antMatchers("/savetocart").permitAll()
			.antMatchers("/deleteitemfromcart").permitAll()
			.antMatchers("/byitems").permitAll()
			.antMatchers("/back").permitAll()
			.anyRequest().authenticated()
			.and()
			.csrf().disable().formLogin()
			.loginPage("/loginadmin")
			.loginPage("/login")
			.loginPage("/login-admin")
			.and()
			.logout()
			.logoutSuccessUrl("/")
			.and()
			.exceptionHandling()
			.accessDeniedPage("/access-denied");
			
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/resources/**", "/static/**", "/css/**", "/js/**", "/images/**");
	}

}
